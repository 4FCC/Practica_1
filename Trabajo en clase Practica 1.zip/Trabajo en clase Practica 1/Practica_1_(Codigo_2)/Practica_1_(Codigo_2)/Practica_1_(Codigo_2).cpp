#include <iostream>

void Normalize(float** matrix, int n, int m) {
    // Encontrar el valor mínimo y máximo en la matriz
    float vmin = matrix[0][0];
    float vmax = matrix[0][0];

    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (matrix[i][j] < vmin) {
                vmin = matrix[i][j];
            }
            if (matrix[i][j] > vmax) {
                vmax = matrix[i][j];
            }
        }
    }

    // Calcular la diferencia entre el valor máximo y mínimo
    float dmm = vmax - vmin;

    // Normalizar la matriz
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            matrix[i][j] = (matrix[i][j] - vmin) / dmm;
        }
    }
}

int main() {
    int n = 3; // Número de filas
    int m = 3; // Número de columnas

    // Crear y llenar la matriz con valores aleatorios entre 0 y 1
    float** matriz = new float* [n];
    std::srand(std::time(0)); // Inicializar la semilla aleatoria

    for (int i = 0; i < n; i++) {
        matriz[i] = new float[m];
        for (int j = 0; j < m; j++) {
            matriz[i][j] = static_cast<float>(std::rand()) / RAND_MAX;
        }
    }

    // Imprimir la matriz original
    std::cout << "Matriz original:" << std::endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            std::cout << matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }

    // Aplicar la función de normalización a la matriz
    Normalize(matriz, n, m);

    // Imprimir la matriz normalizada
    std::cout << "Matriz normalizada:" << std::endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            std::cout << matriz[i][j] << " ";
        }
        std::cout << std::endl;
    }

    // Liberar la memoria de la matriz
    for (int i = 0; i < n; i++) {
        delete[] matriz[i];
    }
    delete[] matriz;

    return 0;
}