#include <iostream>

// Función para sumar dos matrices y devolver el resultado
float** Sum(float** matriz1, float** matriz2, int n, int m) {
    // Crear una nueva matriz para almacenar el resultado
    float** resultado = new float* [n];
    for (int i = 0; i < n; i++) {
        resultado[i] = new float[m];
    }

    // Realizar la suma de las matrices
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            resultado[i][j] = matriz1[i][j] + matriz2[i][j];
        }
    }

    return resultado;
}

int main() {
    int n = 3; // Número de filas
    int m = 3; // Número de columnas

    // Crear y llenar la primera matriz
    float** matriz1 = new float* [n];
    for (int i = 0; i < n; i++) {
        matriz1[i] = new float[m];
        for (int j = 0; j < m; j++) {
            matriz1[i][j] = static_cast<float>(i * m + j);
        }
    }

    // Crear y llenar la segunda matriz
    float** matriz2 = new float* [n];
    for (int i = 0; i < n; i++) {
        matriz2[i] = new float[m];
        for (int j = 0; j < m; j++) {
            matriz2[i][j] = static_cast<float>(i * m + j);
        }
    }

    // Sumar las matrices
    float** resultado = Sum(matriz1, matriz2, n, m);

    // Imprimir el resultado
    std::cout << "Matriz resultado:" << std::endl;
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            std::cout << resultado[i][j] << " ";
        }
        std::cout << std::endl;
    }

    // Liberar la memoria de las matrices y el resultado
    for (int i = 0; i < n; i++) {
        delete[] matriz1[i];
        delete[] matriz2[i];
        delete[] resultado[i];
    }
    delete[] matriz1;
    delete[] matriz2;
    delete[] resultado;

    return 0;
}
